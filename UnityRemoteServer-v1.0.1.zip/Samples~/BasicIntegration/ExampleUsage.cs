#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using DSGarage.UnityRemoteServer;

namespace DSGarage.UnityRemoteServer.Samples
{
    /// <summary>
    /// Example of how to use Unity Remote Server in your project
    /// </summary>
    public static class ExampleUsage
    {
        [MenuItem("Remote Server/Examples/Check Server Status")]
        public static void CheckServerStatus()
        {
            if (RemoteServer.IsRunning)
            {
                Debug.Log($"Remote Server is running on http://127.0.0.1:8787");
            }
            else
            {
                Debug.Log("Remote Server is not running");
                RemoteServer.Start();
            }
        }

        [MenuItem("Remote Server/Examples/Stop Server")]
        public static void StopServer()
        {
            RemoteServer.Stop();
            Debug.Log("Remote Server stopped");
        }

        [MenuItem("Remote Server/Examples/Restart Server")]
        public static void RestartServer()
        {
            RemoteServer.Stop();
            RemoteServer.Start();
            Debug.Log("Remote Server restarted");
        }

        [MenuItem("Remote Server/Examples/Clear Logs")]
        public static void ClearLogs()
        {
            LogStore.Clear();
            Debug.Log("Logs cleared");
        }
    }

    /// <summary>
    /// Example custom endpoint
    /// </summary>
    [InitializeOnLoad]
    public static class CustomEndpointExample
    {
        static CustomEndpointExample()
        {
            // Register custom endpoint on initialization
            RemoteServer.RegisterCustomEndpoint("/api/project/info", GetProjectInfo);
        }

        private static void GetProjectInfo(System.Net.HttpListenerContext ctx)
        {
            var info = new
            {
                projectName = Application.productName,
                unityVersion = Application.unityVersion,
                platform = Application.platform.ToString(),
                timestamp = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };
            
            var json = JsonUtility.ToJson(info);
            RemoteServer.WriteJson(ctx, 200, json);
        }
    }
}
#endif