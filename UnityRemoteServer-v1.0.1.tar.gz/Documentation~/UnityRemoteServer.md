# Unity Remote Server - Technical Documentation

## Architecture

### Core Components

#### RemoteServer.cs
- Main HTTP server implementation
- Handles request routing and response
- Thread management for background listening
- Main thread queue for Unity API calls

#### LogStore.cs
- Centralized log collection
- Early subscription via [InitializeOnLoad]
- Ring buffer implementation (5000 entries max)
- Thread-safe operations

#### RemoteOps.cs
- Unity Editor operations
- Asset management functions
- Build pipeline integration
- Compilation monitoring

### Threading Model

```
[HTTP Request] → [Listener Thread] → [Request Queue] → [Main Thread] → [Response]
```

- HTTP listener runs on background thread
- Unity API calls queued for main thread execution
- Responses sent from main thread after processing

## Extension Points

### Custom Endpoints

```csharp
using DSGarage.UnityRemoteServer;
using System.Net;

public static class MyCustomEndpoints
{
    [InitializeOnLoad]
    static MyCustomEndpoints()
    {
        RemoteServer.RegisterCustomEndpoint("/api/custom", HandleCustom);
    }
    
    static void HandleCustom(HttpListenerContext ctx)
    {
        // Process request
        var method = ctx.Request.HttpMethod;
        var body = ReadRequestBody(ctx.Request);
        
        // Generate response
        var response = ProcessCustomLogic(body);
        
        // Send response
        RemoteServer.WriteJson(ctx, 200, response);
    }
}
```

### Custom Log Processors

```csharp
LogStore.RegisterProcessor((LogEntry entry) => {
    if (entry.type == "Error") {
        // Custom error handling
        NotifyErrorSystem(entry);
    }
});
```

## API Specifications

### Request Format

All requests use standard HTTP methods:
- GET: Retrieve information
- POST: Perform actions
- DELETE: Clear/remove data

Headers:
- Content-Type: application/json (for POST requests)
- Accept: application/json

### Response Format

All responses are JSON formatted:

```json
{
  "ok": true,
  "data": { },
  "error": null
}
```

Error responses:
```json
{
  "ok": false,
  "data": null,
  "error": "Error message"
}
```

### Status Codes

- 200: Success
- 400: Bad request
- 404: Endpoint not found
- 500: Internal server error

## Performance Considerations

### Memory Management
- Log buffer limited to 5000 entries
- Old entries automatically removed
- Request bodies limited to reasonable sizes

### Threading
- Single listener thread per server instance
- Main thread operations batched
- Async operations where possible

### Optimization Tips
- Use level filtering for log queries
- Implement pagination for large datasets
- Cache frequently accessed data

## Security

### Access Control
- Localhost only (127.0.0.1)
- No external network access
- No authentication (localhost trust)

### Best Practices
- Never expose to public networks
- Validate all input data
- Sanitize file paths
- Limit operation scope

## Troubleshooting

### Common Issues

#### Port Already in Use
```csharp
// Check if port is available
RemoteServer.Stop();
RemoteServer.Port = 8788; // Try different port
RemoteServer.Start();
```

#### Server Not Starting
1. Check Unity Console for errors
2. Verify no firewall blocking
3. Ensure Editor is in play mode (if required)

#### Compilation Hanging
- Check for infinite loops in code
- Verify no circular dependencies
- Clear Library folder if needed

### Debug Mode

Enable verbose logging:
```csharp
RemoteServer.EnableDebugLogging = true;
```

## Integration Examples

### CI/CD Pipeline

```bash
#!/bin/bash
# Automated build script

# Wait for Unity to start
until curl -s http://127.0.0.1:8787/health; do
  sleep 1
done

# Refresh assets
curl -X POST http://127.0.0.1:8787/refresh -d '{"force":true}'

# Wait for compilation
curl -X POST http://127.0.0.1:8787/awaitCompile -d '{"timeoutSec":300}'

# Check for errors
ERRORS=$(curl -s "http://127.0.0.1:8787/errors?level=error")
if [ $(echo $ERRORS | jq '. | length') -gt 0 ]; then
  echo "Build has errors"
  exit 1
fi

# Trigger build
curl -X POST http://127.0.0.1:8787/build \
  -d '{"platform":"android","outputPath":"build.apk"}'
```

### Monitoring Dashboard

```javascript
// JavaScript monitoring client
class UnityMonitor {
  constructor() {
    this.baseUrl = 'http://127.0.0.1:8787';
  }
  
  async getStatus() {
    const health = await fetch(`${this.baseUrl}/health`);
    const errors = await fetch(`${this.baseUrl}/errors?level=error&limit=10`);
    return {
      healthy: health.ok,
      errors: await errors.json()
    };
  }
  
  async refreshAndCompile() {
    await fetch(`${this.baseUrl}/refresh`, { method: 'POST' });
    await fetch(`${this.baseUrl}/awaitCompile`, { method: 'POST' });
  }
}
```