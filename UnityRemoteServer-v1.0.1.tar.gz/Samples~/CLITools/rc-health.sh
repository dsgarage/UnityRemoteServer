#!/usr/bin/env bash
# Unity Remote Server - Health Check
set -euo pipefail

PORT="${UNITY_REMOTE_PORT:-8787}"
HOST="${UNITY_REMOTE_HOST:-127.0.0.1}"

curl -sS "http://${HOST}:${PORT}/health" | jq . || echo "Remote Server not responding"