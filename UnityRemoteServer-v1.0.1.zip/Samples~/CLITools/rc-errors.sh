#!/usr/bin/env bash
# Unity Remote Server - Error Management
set -euo pipefail

PORT="${UNITY_REMOTE_PORT:-8787}"
HOST="${UNITY_REMOTE_HOST:-127.0.0.1}"
BASE_URL="http://${HOST}:${PORT}"

CMD="${1:-get}"
LEVEL="${2:-error}"
LIMIT="${3:-200}"

if [ "$CMD" = "clear" ]; then
    echo "Clearing logs..."
    curl -sS -X POST "${BASE_URL}/errors/clear" \
      -H 'Content-Type: application/json' \
      -d '{}' | jq .
else
    curl -sS "${BASE_URL}/errors?level=${LEVEL}&limit=${LIMIT}" | jq .
fi