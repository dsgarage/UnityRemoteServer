#!/usr/bin/env bash
# Unity Remote Server - Refresh and Compile
set -euo pipefail

PORT="${UNITY_REMOTE_PORT:-8787}"
HOST="${UNITY_REMOTE_HOST:-127.0.0.1}"
BASE_URL="http://${HOST}:${PORT}"

echo "Refreshing assets..."
curl -sS -X POST "${BASE_URL}/refresh" \
  -H 'Content-Type: application/json' \
  -d '{"force":true}' | jq .

echo "Waiting for compilation..."
curl -sS -X POST "${BASE_URL}/awaitCompile" \
  -H 'Content-Type: application/json' \
  -d '{"timeoutSec":120}' | jq .

echo "Done!"